package algebre;

public class Vecteur2D extends Vecteur {
	public Vecteur2D(double x, double y) {
		super(2);
		coords[0] = x;
		coords[1] = y;
	}
	
// sinus de l'angle de i à this
	public double sinus() {
		return 0; //todo: return the results of your computation instead
	}
	
// cosinus de l'angle de i à this
	public double cosinus() {
		return 0; //todo: return the results of your computation instead
	}
	
// tangente de l'angle de i à this
// attention this ne doit pas être vertical...
	public double tangente() {
		return 0; //todo: return the results of your computation instead
	}
	
	public double angle() {
		return 0; //todo: return the results of your computation instead
	}

	public double cosinus(Vecteur2D v) {
		return 0; //todo: return the results of your computation instead
	}
	
	private double det(Vecteur2D v) {
		return 0; //todo: return the results of your computation instead
	}

	public double sinus(Vecteur2D v) {
		return 0; //todo: return the results of your computation instead
	}

	public double angle(Vecteur2D s2) {
		return 0; //todo: return the results of your computation instead
	}
}
