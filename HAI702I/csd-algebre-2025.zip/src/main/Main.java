package main;

import algebre.Matrice;

public class Main {

	public static void main(String s[]) {
		//todo tests 
		
		// starting with example from TD
		double coef[][] = { { 1, 1, 2 }, { 1, 2, 1 }, { 2, 1, 1 } };
		Matrice m = new Matrice(coef);
		m.print();

		//todo
	}
}
