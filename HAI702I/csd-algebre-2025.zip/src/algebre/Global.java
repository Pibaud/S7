package algebre;

public class Global {
	public static double precision = 9 * 1.E-15;

}
